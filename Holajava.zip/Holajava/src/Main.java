public class Main {
    public static void main (String[] args) {
        int resultado;
        resultado = suma(30,  30, 50);

        System.out.println(resultado);
    }
    public static int suma(int a, int b, int c) {
            return a + b + c;
            
    }
}
